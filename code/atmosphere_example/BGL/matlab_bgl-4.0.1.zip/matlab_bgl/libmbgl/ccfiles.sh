#!/bin/bash -e

CCFILES="components.cc max_flow.cc orderings.cc searches.cc shortest_path.cc
spanning_trees.cc statistics.cc layouts.cc planar.cc"

